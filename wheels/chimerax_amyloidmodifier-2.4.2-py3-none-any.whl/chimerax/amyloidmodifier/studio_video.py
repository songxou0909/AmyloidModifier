"""Bounded, frame-exact MP4 encoding with ChimeraX's bundled FFmpeg.

The web channel never supplies paths or command-line arguments. PNGs are piped
to a worker; only the completed MP4 is returned to the existing save workflow.
No FFmpeg distribution or additional Python dependency is bundled here.
"""
import base64
import json
import os
from pathlib import Path
import queue
import struct
import subprocess
import sys
import tempfile
import threading
import time
import uuid

MAX_BYTES = 600 * 1048576
READ_BYTES = 256 * 1024


def bundled_ffmpeg():
    name = 'ffmpeg.exe' if sys.platform == 'win32' else 'ffmpeg'
    try:
        from chimerax import app_bin_dir
    except ImportError:
        app_bin_dir = os.path.dirname(sys.executable)
    path = Path(app_bin_dir) / name
    if not path.is_file():
        raise ValueError('ChimeraX\'s bundled FFmpeg was not found. Use H.264 in a supported browser, or lossless MOV.')
    return str(path)


def integer(value, low, high, label):
    if isinstance(value, bool) or not isinstance(value, (int, float)) or int(value) != value or not low <= value <= high:
        raise ValueError('Invalid ' + label + '.')
    return int(value)


class _Movie:
    def __init__(self, settings, executable):
        self.width = integer(settings.get('width'), 2, 7680, 'video width')
        self.height = integer(settings.get('height'), 2, 7680, 'video height')
        if self.width % 2 or self.height % 2 or self.width * self.height > 17000000:
            raise ValueError('MP4 needs even dimensions within 17 megapixels.')
        self.fps = integer(settings.get('fps'), 1, 120, 'frame rate')
        bitrate = integer(settings.get('bitrate'), 1, 200000000, 'bitrate')
        codec = settings.get('codec')
        if codec not in ('avc', 'hevc'):
            raise ValueError('Choose H.264 or H.265.')
        self.ident = uuid.uuid4().hex
        self.frames = 0
        self.pending = False
        self.finishing = self.done = self.cancelled = False
        self.error = None
        self.queue = queue.Queue(maxsize=1)
        self.temporary = tempfile.TemporaryDirectory(prefix='amyloid-mp4-')
        self.output = Path(self.temporary.name) / 'movie.mp4'
        self.log = open(Path(self.temporary.name) / 'encoder.log', 'w+b')
        self.process = None
        args = [executable, '-hide_banner', '-loglevel', 'error', '-y',
                '-f', 'image2pipe', '-vcodec', 'png', '-framerate', str(self.fps), '-i', 'pipe:0',
                '-an', '-c:v', 'libx265' if codec == 'hevc' else 'libx264',
                '-preset', 'fast', '-threads', '2', '-pix_fmt', 'yuv420p', '-b:v', str(bitrate),
                '-movflags', '+faststart']
        if codec == 'hevc':
            # Older ChimeraX FFmpeg builds accept hev1 but reject an explicit
            # hvc1 tag. Let the MP4 muxer choose its supported HEVC sample entry.
            args += ['-x265-params', 'pools=2:frame-threads=2:log-level=error']
        args += ['-f', 'mp4', str(self.output)]
        try:
            self.process = subprocess.Popen(args, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                                            stderr=self.log, creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except Exception:
            self.log.close()
            self.temporary.cleanup()
            raise
        self.worker = threading.Thread(target=self._encode, name='Amyloid MP4 encoder', daemon=True)
        self.worker.start()

    def _encode(self):
        try:
            while not self.cancelled:
                try:
                    frame = self.queue.get(timeout=.2)
                except queue.Empty:
                    if self.process.poll() is not None:
                        raise ValueError('The native video encoder stopped.')
                    continue
                if frame is None:
                    break
                self.process.stdin.write(frame)
                self.process.stdin.flush()
                self.pending = False
                if self.size() > MAX_BYTES:
                    raise ValueError('MP4 exceeded the 600 MB export budget.')
            self.process.stdin.close()
            if self.cancelled:
                return
            code = self.process.wait(timeout=180)
            if code or not self.output.is_file() or not self.output.stat().st_size:
                raise ValueError('The native video encoder could not finish the MP4.')
            if self.size() > MAX_BYTES:
                raise ValueError('MP4 exceeded the 600 MB export budget.')
            self.done = True
        except Exception as exc:
            if not self.cancelled:
                self.process.kill() if self.process.poll() is None else None
                self.process.wait()
                self.log.flush()
                self.log.seek(max(0, self.log.seek(0, 2) - 3000))
                detail = self.log.read().decode('utf-8', errors='replace').strip()
                self.error = str(exc) + (' ' + detail if detail else '')
        finally:
            if self.process.poll() is None:
                self.process.kill()
            self.process.wait()
            if not self.process.stdin.closed:
                try:
                    self.process.stdin.close()
                except OSError:
                    pass
            self.log.close()
            if self.cancelled:
                self.temporary.cleanup()

    def size(self):
        try:
            return self.output.stat().st_size
        except FileNotFoundError:
            return 0

    def status(self):
        if self.error:
            raise ValueError(self.error)
        if self.cancelled:
            raise ValueError('Video export canceled.')
        return {'pending': self.pending, 'done': self.done, 'bytes': self.size(), 'frames': self.frames}

    def add(self, encoded, index):
        self.status()
        if self.finishing or self.pending or index != self.frames or self.frames >= 28800:
            raise ValueError('Video frames arrived out of order or exceeded the export limit.')
        max_png = self.width * self.height * 5 + 1048576
        if not isinstance(encoded, str) or len(encoded) > (max_png + 2) // 3 * 4:
            raise ValueError('Invalid PNG video frame size.')
        png = base64.b64decode(encoded, validate=True)
        if (len(png) < 33 or png[:8] != b'\x89PNG\r\n\x1a\n' or png[12:16] != b'IHDR'
                or struct.unpack('>II', png[16:24]) != (self.width, self.height)):
            raise ValueError('The PNG video frame dimensions changed during export.')
        self.pending = True
        self.queue.put_nowait(png)
        self.frames += 1
        return self.status()

    def finish(self):
        self.status()
        if not self.frames or self.pending:
            raise ValueError('No completed video frames are ready to save.')
        if not self.finishing:
            self.finishing = True
            self.queue.put_nowait(None)
        return self.status()

    def read(self, offset):
        self.status()
        if not self.done:
            raise ValueError('The MP4 is still encoding.')
        offset = integer(offset, 0, self.size(), 'MP4 read position')
        with self.output.open('rb') as stream:
            stream.seek(offset)
            data = stream.read(READ_BYTES)
        return {'data': base64.b64encode(data).decode('ascii'), 'next': offset + len(data)}

    def close(self):
        self.cancelled = True
        if self.process.poll() is None:
            self.process.kill()
        # Reaping/temporary cleanup runs off the Qt event loop, including while
        # the writer is blocked in an OS pipe. Never delete an active output.
        def reap():
            self.worker.join()
            self.temporary.cleanup()
        threading.Thread(target=reap, name='Amyloid MP4 cleanup', daemon=True).start()


class StudioVideoService:
    def __init__(self, executable=None):
        self.executable = executable
        self.movie = None

    def request(self, payload):
        try:
            request = json.loads(payload)
            op = request.get('op')
            if op == 'begin':
                if self.movie is not None:
                    raise ValueError('A video export is already active.')
                self.movie = _Movie(request, self.executable or bundled_ffmpeg())
                result = {'id': self.movie.ident}
            else:
                movie = self.movie
                if movie is None or request.get('id') != movie.ident:
                    raise ValueError('This video export is no longer active.')
                if op == 'add':
                    result = movie.add(request.get('png'), request.get('index'))
                elif op == 'status':
                    result = movie.status()
                elif op == 'finish':
                    result = movie.finish()
                elif op == 'read':
                    result = movie.read(request.get('offset'))
                elif op == 'close':
                    self.close()
                    result = {}
                else:
                    raise ValueError('Unknown video export operation.')
            return json.dumps(result)
        except Exception as exc:
            return json.dumps({'error': str(exc)})

    def close(self):
        if self.movie is not None:
            self.movie.close()
            self.movie = None

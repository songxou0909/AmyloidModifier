"""Read a preset's local structure path without opening or modifying a model."""
import os


def read_source(path):
    missing = {'available': False}
    if not isinstance(path, str) or not path or not os.path.isabs(path):
        return dict(missing, reason='The preset has no absolute structure path.')
    if os.path.splitext(path)[1].lower() not in ('.pdb', '.cif', '.mmcif', '.ent'):
        return dict(missing, reason='The saved path is not a supported structure file.')
    try:
        with open(path, 'rb') as stream:
            data = stream.read(40 * 1024 * 1024 + 1)
        if len(data) > 40 * 1024 * 1024:
            return dict(missing, reason='The saved structure exceeds the 40 MB import limit.')
        return {'available': True, 'path': os.path.abspath(path),
                'name': os.path.basename(path), 'text': data.decode('utf-8-sig', errors='replace')}
    except (OSError, ValueError):
        return dict(missing, reason='The saved structure path is missing or unreadable.')
